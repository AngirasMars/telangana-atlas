// src/firebase.js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";


const firebaseConfig = {
  apiKey: "AIzaSyAE3ozRgeolrPS0yWELQk-aZX9zItOKy0Q",
  authDomain: "telangana-atlas.firebaseapp.com",
  projectId: "telangana-atlas",
  storageBucket: "telangana-atlas.firebasestorage.appspot.com",
  messagingSenderId: "332249760365",
  appId: "1:332249760365:web:717cd454c7baee8ddfb564",
};

const app = initializeApp(firebaseConfig);


export const auth = getAuth(app);
export const db = getFirestore(app);       
export const storage = getStorage(app);    

