// src/components/DistrictCharchaPanel.js
import React, { useEffect, useState } from "react";
import { db, auth } from "../firebase";
import {
  collection,
  addDoc,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
} from "firebase/firestore";

const DistrictCharchaPanel = ({
  district,
  isPlacingPin,
  setIsPlacingPin,
  pendingPinCoords,
  setPendingPinCoords,
}) => {
  const [text, setText] = useState("");
  const [posts, setPosts] = useState([]);
  const [loadingPosts, setLoadingPosts] = useState(true);
  const [pinNoticeShown, setPinNoticeShown] = useState(false);

  useEffect(() => {
    if (!district?.district) {
      setPosts([]);
      return;
    }

    setLoadingPosts(true);
    const districtId = district.district;

    const q = query(
      collection(db, "charcha", districtId, "posts"),
      orderBy("timestamp", "desc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const newPosts = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setPosts(newPosts);
      setLoadingPosts(false);
    });

    return () => {
      unsubscribe();
      setPosts([]);
    };
  }, [district?.district]);

  const handlePost = async () => {
    const user = auth.currentUser;
    if (!text.trim() || !user || !district?.district) return;

    try {
      const postData = {
        text: text.trim(),
        userId: user.uid,
        userName: user.email.split("@")[0],
        timestamp: serverTimestamp(),
      };

      if (pendingPinCoords) {
        postData.lat = pendingPinCoords.lat;
        postData.lng = pendingPinCoords.lng;
      }

      await addDoc(collection(db, "charcha", district.district, "posts"), postData);

      setText("");
      setPendingPinCoords(null);
      setPinNoticeShown(false);
    } catch (error) {
      console.error("Failed to post:", error);
    }
  };

  const handleAttachPin = () => {
    setIsPlacingPin(true);
    setPendingPinCoords(null);
    setPinNoticeShown(true);
  };

  // 👇 Scroll-to-post on pin click from map
  useEffect(() => {
    const handleScrollToPost = (e) => {
      const { postId } = e.detail;
      const el = document.getElementById(`post-${postId}`);
      if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "center" });
        el.classList.add("ring", "ring-pink-500");
        setTimeout(() => el.classList.remove("ring", "ring-pink-500"), 2000);
      }
    };

    window.addEventListener("scroll-to-post", handleScrollToPost);
    return () => window.removeEventListener("scroll-to-post", handleScrollToPost);
  }, []);

  return (
    <div className="text-white space-y-4 p-4">
      <h2 className="text-2xl font-bold text-pink-400">
        Charcha in {district.district}
      </h2>

      {/* Post Form */}
      <div className="space-y-2">
        {pinNoticeShown && !pendingPinCoords && (
          <div className="text-sm text-yellow-400 italic">
            Click on the map to drop your pin…
          </div>
        )}

        {pendingPinCoords && (
          <div className="text-xs text-green-400">
            📍 Pin attached at: {pendingPinCoords.lat.toFixed(4)}, {pendingPinCoords.lng.toFixed(4)}
          </div>
        )}

        <textarea
          className="w-full p-3 rounded bg-gray-800 border border-gray-600"
          placeholder="What's happening in this district?"
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={3}
          disabled={isPlacingPin}
        />

        <div className="flex gap-2">
          <button
            onClick={handlePost}
            className="bg-pink-600 px-4 py-2 rounded hover:bg-pink-700 transition"
            disabled={isPlacingPin}
          >
            Post
          </button>

          <button
            onClick={handleAttachPin}
            className="bg-gray-700 px-4 py-2 rounded hover:bg-gray-600 text-sm"
            disabled={isPlacingPin}
          >
            📍 Attach Pin
          </button>
        </div>
      </div>

      {/* Post Feed */}
      <div className="space-y-4 max-h-[60vh] overflow-y-auto">
        {loadingPosts ? (
          <p className="text-sm text-gray-400 italic">Loading posts...</p>
        ) : posts.length === 0 ? (
          <p className="text-sm text-gray-400 italic">No posts yet. Be the first!</p>
        ) : (
          posts.map((post) => (
            <div
              id={`post-${post.id}`}
              key={post.id}
              className="bg-gray-800 border border-gray-700 p-3 rounded transition-all duration-500"
            >
              <div className="text-sm text-pink-300 font-semibold">@{post.userName}</div>
              <p className="text-base mt-1">{post.text}</p>
              {post.lat && post.lng && (
                <p className="text-xs text-gray-400 mt-1">
                  📍 Location: {post.lat.toFixed(3)}, {post.lng.toFixed(3)}
                </p>
              )}
              <div className="text-xs text-gray-500 mt-1">
                {post.timestamp?.toDate()?.toLocaleString() || "Just now"}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default DistrictCharchaPanel;
