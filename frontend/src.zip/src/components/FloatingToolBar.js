// src/components/FloatingToolBar.js
import React, { useState } from "react";
import DistrictStatsPanel from "./DistrictStatsPanel";
import ComparePanel from "./ComparePanel";
import GeminiChatPanel from "./GeminiChatPanel";
import FloatingPanel from "./FloatingPanel";
import DistrictCharchaPanel from "./DistrictCharchaPanel";

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

const FloatingToolBar = ({
  selectedDistrict,
  isPlacingPin,
  setIsPlacingPin,
  pendingPinCoords,
  setPendingPinCoords
}) => {
  const [selectedTabIndex, setSelectedTabIndex] = useState(null); // null = no tab open

  const isDistrictSelected = !!selectedDistrict;

  const tabs = [
    {
      name: "District Stats",
      show: isDistrictSelected,
      content: (
        <FloatingPanel
          title={`District: ${selectedDistrict?.district}`}
          onClose={() => setSelectedTabIndex(null)}
        >
          <DistrictStatsPanel district={selectedDistrict} />
        </FloatingPanel>
      ),
    },
    {
      name: "Compare",
      show: true,
      content: (
        <FloatingPanel
          title="Compare Districts"
          onClose={() => setSelectedTabIndex(null)}
        >
          <ComparePanel />
        </FloatingPanel>
      ),
    },
    {
      name: "Gemini",
      show: isDistrictSelected,
      content: (
        <FloatingPanel
          title="Talk to Gemini AI"
          onClose={() => setSelectedTabIndex(null)}
        >
          <GeminiChatPanel
            selectedDistrict={selectedDistrict}
            isCompareMode={false}
            comparisonContext={null}
          />
        </FloatingPanel>
      ),
    },
    {
      name: "Charcha",
      show: isDistrictSelected,
      content: (
        <FloatingPanel
          title={`Charcha: ${selectedDistrict?.district}`}
          onClose={() => setSelectedTabIndex(null)}
        >
          <DistrictCharchaPanel
            district={selectedDistrict}
            isPlacingPin={isPlacingPin}
            setIsPlacingPin={setIsPlacingPin}
            pendingPinCoords={pendingPinCoords}
            setPendingPinCoords={setPendingPinCoords}
          />
        </FloatingPanel>
      ),
    },
  ];

  return (
    <div className="absolute top-3 right-4 z-50">
      {/* Tab Selector Bar */}
      <div className="flex space-x-2 bg-gray-800 p-2 rounded-xl shadow-lg">
        {tabs.map(
          (tab, index) =>
            tab.show && (
              <button
                key={tab.name}
                onClick={() => setSelectedTabIndex(index)}
                className={classNames(
                  "px-4 py-2 rounded-md font-semibold text-sm transition-all",
                  selectedTabIndex === index
                    ? "bg-pink-600 text-white"
                    : "bg-gray-700 text-gray-300 hover:bg-gray-600"
                )}
              >
                {tab.name}
              </button>
            )
        )}
      </div>

      {/* Panel Content */}
      {selectedTabIndex !== null && tabs[selectedTabIndex].content}
    </div>
  );
};

export default FloatingToolBar;
