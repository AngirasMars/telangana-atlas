// src/components/Map.js
import React, { useEffect, useRef, useState } from "react";
import mapboxgl from "mapbox-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import districtData from "../data/districts_enriched.json";
import * as turf from "@turf/turf";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../firebase";

mapboxgl.accessToken = process.env.REACT_APP_MAPBOX_TOKEN;

function Map({ setSelectedDistrict, selectedDistrict, isPlacingPin, onPinPlaced }) {
  const mapContainer = useRef(null);
  const map = useRef(null);
  const [telanganaGeoJson, setTelanganaGeoJson] = useState(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [pinGeoJson, setPinGeoJson] = useState(null);

  useEffect(() => {
    fetch("/telangana_districts.geojson")
      .then((res) => res.json())
      .then(setTelanganaGeoJson)
      .catch((err) => console.error("Failed to load GeoJSON:", err));
  }, []);

  useEffect(() => {
    if (map.current) return;

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: "mapbox://styles/mapbox/dark-v10",
      center: [79.0193, 17.9784],
      zoom: 6.1,
      maxBounds: [
        [77.0, 15.8],
        [82.0, 19.6],
      ],
    });

    map.current.on("load", () => {
      setMapLoaded(true);
      if (telanganaGeoJson) addMapLayers(map.current, telanganaGeoJson);
    });

    // 🔥 NEW: Global map click
    map.current.on("click", (e) => {
      if (isPlacingPin) {
        const { lng, lat } = e.lngLat;
        onPinPlaced({ lat, lng });
        return;
      }

      const features = map.current.queryRenderedFeatures(e.point, {
        layers: ["districts-fill"],
      });

      if (features.length) {
        const name = features[0].properties.district;
        const match = districtData.find((d) =>
          d.district.toLowerCase() === name.toLowerCase()
        );
        if (match) {
          setSelectedDistrict(match);
        }
      }
    });

    map.current.on("mouseenter", "districts-fill", () => {
      map.current.getCanvas().style.cursor = "pointer";
    });

    map.current.on("mouseleave", "districts-fill", () => {
      map.current.getCanvas().style.cursor = "";
    });

    return () => {
      map.current?.remove();
      map.current = null;
    };
  }, []);

  useEffect(() => {
    if (
      map.current &&
      mapLoaded &&
      telanganaGeoJson &&
      !map.current.getSource("telangana")
    ) {
      addMapLayers(map.current, telanganaGeoJson);
    }
  }, [mapLoaded, telanganaGeoJson]);

  useEffect(() => {
    if (!map.current) return;
    map.current.getCanvas().style.cursor = isPlacingPin ? "crosshair" : "";
  }, [isPlacingPin]);

  useEffect(() => {
    if (!map.current || !mapLoaded || !selectedDistrict || !telanganaGeoJson)
      return;

    map.current.setFilter("districts-highlight", ["==", "district", ""]);

    const feature = telanganaGeoJson.features.find(
      (f) =>
        f.properties?.district?.toUpperCase() ===
        selectedDistrict.district.toUpperCase()
    );

    if (feature) {
      const bbox = turf.bbox(feature.geometry);
      map.current.fitBounds(bbox, { padding: 50, duration: 1000 });

      map.current.setFilter("districts-highlight", [
        "==",
        ["upcase", ["get", "district"]],
        selectedDistrict.district.toUpperCase(),
      ]);
    }
  }, [selectedDistrict, telanganaGeoJson, mapLoaded]);

  useEffect(() => {
    const fetchPins = async () => {
      if (!selectedDistrict?.district) {
        setPinGeoJson(null);
        return;
      }

      const colRef = collection(db, "charcha", selectedDistrict.district, "posts");
      const snapshot = await getDocs(colRef);
      const features = [];

      snapshot.forEach((doc) => {
        const data = doc.data();
        if (data.lat && data.lng) {
          features.push({
            type: "Feature",
            geometry: {
              type: "Point",
              coordinates: [data.lng, data.lat],
            },
            properties: {
              text: data.text,
              userName: data.userName,
              postId: doc.id,
            },
          });
        }
      });

      setPinGeoJson({
        type: "FeatureCollection",
        features,
      });
    };

    fetchPins();
  }, [selectedDistrict]);

  useEffect(() => {
    if (!map.current || !mapLoaded || !pinGeoJson) return;

    const sourceId = "charcha-pins";
    const layerId = "charcha-pin-layer";

    if (map.current.getSource(sourceId)) {
      map.current.getSource(sourceId).setData(pinGeoJson);
    } else {
      map.current.addSource(sourceId, {
        type: "geojson",
        data: pinGeoJson,
      });

      map.current.addLayer({
        id: layerId,
        type: "symbol",
        source: sourceId,
        layout: {
          "icon-image": "marker-15",
          "icon-size": 1.5,
          "icon-allow-overlap": true,
          "text-field": ["get", "userName"],
          "text-size": 12,
          "text-anchor": "top",
          "text-offset": [0, 1.2],
        },
        paint: {
          "text-color": "#FF66B3",
        },
      });

      map.current.on("click", layerId, (e) => {
        const coordinates = e.features[0].geometry.coordinates.slice();
        const { text, userName, postId } = e.features[0].properties;

        new mapboxgl.Popup()
          .setLngLat(coordinates)
          .setHTML(`<strong>@${userName}</strong><p>${text}</p>`)
          .addTo(map.current);

        // 🔥 Scroll to Charcha post
        window.dispatchEvent(
          new CustomEvent("scroll-to-post", { detail: { postId } })
        );
      });

      map.current.on("mouseenter", layerId, () => {
        map.current.getCanvas().style.cursor = "pointer";
      });

      map.current.on("mouseleave", layerId, () => {
        map.current.getCanvas().style.cursor = "";
      });
    }
  }, [pinGeoJson, mapLoaded]);

  const addMapLayers = (map, geojsonData) => {
    if (!map.getSource("telangana")) {
      map.addSource("telangana", {
        type: "geojson",
        data: geojsonData,
      });

      map.addLayer({
        id: "districts-fill",
        type: "fill",
        source: "telangana",
        paint: {
          "fill-color": [
            "interpolate",
            ["linear"],
            ["get", "density"],
            0, "#F8BBD0",
            100, "#fee0d2",
            500, "#fc9272",
            5000, "#de2d26",
          ],
          "fill-opacity": 0.2,
        },
      });

      map.addLayer({
        id: "districts-outline",
        type: "line",
        source: "telangana",
        paint: {
          "line-color": "#ffffff",
          "line-width": 1.5,
        },
      });

      map.addLayer({
        id: "districts-highlight",
        type: "line",
        source: "telangana",
        paint: {
          "line-color": "#FFD700",
          "line-width": 3,
        },
        filter: ["==", "district", ""],
      });

      map.addLayer({
        id: "district-names",
        type: "symbol",
        source: "telangana",
        layout: {
          "text-field": ["get", "district"],
          "text-font": ["Open Sans Bold", "Arial Unicode MS Bold"],
          "text-size": 12,
          "text-allow-overlap": false,
          "text-ignore-placement": false,
        },
        paint: {
          "text-color": "#FFFFFF",
          "text-halo-color": "#000000",
          "text-halo-width": 1.5,
          "text-opacity": [
            "step",
            ["zoom"],
            0,
            6.5,
            1,
          ],
        },
      });
    }
  };

  return <div ref={mapContainer} className="map-container h-full w-full" />;
}

export default Map;
